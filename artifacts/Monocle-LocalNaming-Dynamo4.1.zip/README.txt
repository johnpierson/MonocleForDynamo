Monocle local group naming experiment - Dynamo 4.1

This package downloads and runs Qwen3 4B locally through llama.cpp. Dynamo node
names are not sent to an external AI service.

Install
1. Close Dynamo and Revit.
2. Copy the Monocle folder into:
   %APPDATA%\Dynamo\Dynamo Core\4.1\packages\
3. Start Dynamo 4.1 and check this item in the Monocle menu:
   local group naming (local AI)
4. Review and accept the llama.cpp MIT License and Qwen3 Apache License 2.0.
5. Allow the approximately 2.5 GB download and checksum verification to finish.
6. Select nodes and create a group with an existing Monocle group preset.

The accepted version and downloaded files persist under:
%LOCALAPPDATA%\Monocle\LocalGroupNaming\qwen3-4b-q4km-llama-b10075-v1\

Later sessions reuse those files without asking again. While the menu item is
checked, the local server stays running and names new groups automatically.
The enabled state lasts only for the current Dynamo session and is not retained
after Dynamo closes. Uncheck the item at any time to stop the local server; the
downloaded files remain available for the next enable.

Runtime: llama.cpp b10075, Windows x64 CPU (MIT)
Model: Qwen3-4B-Q4_K_M.gguf, 2.5 GB (Apache-2.0)
Context: 2,048 tokens, four CPU threads

Sources
https://github.com/ggml-org/llama.cpp/releases/tag/b10075
https://huggingface.co/ggml-org/Qwen3-4B-GGUF/blob/main/Qwen3-4B-Q4_K_M.gguf
